#!/bin/sh
printf 'KMP demo instalado\n'
