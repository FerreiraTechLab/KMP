Pacote de demonstração para testar o KDownloader.
